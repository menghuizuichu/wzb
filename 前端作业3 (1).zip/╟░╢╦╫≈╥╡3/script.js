// script.js

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// 设置canvas的真实尺寸，适应容器大小
canvas.width = 800;  // 与CSS中canvas容器的宽度一致
canvas.height = 400; // 与CSS中canvas容器的高度一致

// 生成随机颜色
function randomColor() {
  return `hsl(${Math.random() * 360}, 100%, 50%)`;
}

// 球的构造函数
class Ball {
  constructor(x, y, radius, color, dx, dy) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.color = color;
    this.dx = dx; // 水平方向速度
    this.dy = dy; // 垂直方向速度
  }

  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.closePath();
  }

  update(balls) {
    this.x += this.dx;
    this.y += this.dy;

    // 碰到边界时反弹
    if (this.x + this.radius > canvas.width || this.x - this.radius < 0) {
      this.dx = -this.dx;
    }
    if (this.y + this.radius > canvas.height || this.y - this.radius < 0) {
      this.dy = -this.dy;
    }

    // 碰撞检测
    for (let i = 0; i < balls.length; i++) {
      if (this === balls[i]) continue;
      const dist = Math.hypot(this.x - balls[i].x, this.y - balls[i].y);
      if (dist - this.radius * 2 < 0) {
        // 碰撞后改变颜色
        this.color = randomColor();
        balls[i].color = randomColor();

        // 简单的碰撞响应，反弹
        this.dx = -this.dx;
        this.dy = -this.dy;
      }
    }

    this.draw();
  }
}

// 生成小球
const balls = [];
const ballCount = 10; // 设置小球数量
for (let i = 0; i < ballCount; i++) {
  const radius = 30;
  let x = Math.random() * (canvas.width - radius * 2) + radius;
  let y = Math.random() * (canvas.height - radius * 2) + radius;
  const dx = (Math.random() - 0.5) * 4;
  const dy = (Math.random() - 0.5) * 4;
  const color = randomColor();

  // 防止小球重叠生成
  for (let j = 0; j < balls.length; j++) {
    const dist = Math.hypot(x - balls[j].x, y - balls[j].y);
    if (dist - radius * 2 < 0) {
      x = Math.random() * (canvas.width - radius * 2) + radius;
      y = Math.random() * (canvas.height - radius * 2) + radius;
      j = -1;
    }
  }

  balls.push(new Ball(x, y, radius, color, dx, dy));
}

// 动画循环
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  balls.forEach(ball => ball.update(balls));
  requestAnimationFrame(animate);
}

animate();
