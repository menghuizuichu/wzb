// script.js
const animateBox = document.querySelector('.animate-box');

animateBox.addEventListener('click', () => {
  if (animateBox.style.animationPlayState === 'paused') {
    animateBox.style.animationPlayState = 'running';
  } else {
    animateBox.style.animationPlayState = 'paused';
  }
});
